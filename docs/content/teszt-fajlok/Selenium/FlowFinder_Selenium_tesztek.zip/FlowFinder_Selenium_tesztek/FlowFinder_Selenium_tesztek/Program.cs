﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;

ChromeOptions options = new ChromeOptions();
options.AddArgument("--start-maximized");
options.AddArgument("--disable-notifications");

IWebDriver driver = new ChromeDriver(options);
WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(20));
IJavaScriptExecutor js = (IJavaScriptExecutor)driver;

string baseUrl = "http://frontend.vm1.test";

string idopont = DateTime.Now.ToString("HHmmssfff");
string username = "selenium" + idopont;
string email = username + "@test.hu";
string password = "User123!";
string spotCim = "Selenium spot " + idopont;

string kepPath = Path.Combine(Path.GetTempPath(), "flowfinder-teszt-kep.png");
File.WriteAllBytes(kepPath, Convert.FromBase64String(
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+/p9sAAAAASUVORK5CYII="
));

void Futtat(string kod, string nev, Action lepes)
{
    Console.Write(kod + " - " + nev + " ... ");

    try
    {
        lepes();
        Console.WriteLine("Sikeres!");
    }
    catch
    {
        Console.WriteLine("Sikertelen");
        throw;
    }
}

void Megnyit(string url)
{
    driver.Navigate().GoToUrl(baseUrl + url);
    VarjBetoltesre();
}

void VarjBetoltesre()
{
    wait.Until(d =>
    {
        object? state = ((IJavaScriptExecutor)d).ExecuteScript("return document.readyState");
        return state?.ToString() == "complete";
    });

    Thread.Sleep(300);
}

IWebElement ElemCss(string css)
{
    return wait.Until(d =>
    {
        IReadOnlyCollection<IWebElement> elemek = d.FindElements(By.CssSelector(css));

        foreach (IWebElement elem in elemek)
        {
            if (elem.Displayed && elem.Enabled)
            {
                return elem;
            }
        }

        return null;
    })!;
}

IWebElement ElemXpath(string xpath)
{
    return wait.Until(d =>
    {
        IReadOnlyCollection<IWebElement> elemek = d.FindElements(By.XPath(xpath));

        foreach (IWebElement elem in elemek)
        {
            if (elem.Displayed && elem.Enabled)
            {
                return elem;
            }
        }

        return null;
    })!;
}

IWebElement NyersCss(string css)
{
    return wait.Until(d =>
    {
        IReadOnlyCollection<IWebElement> elemek = d.FindElements(By.CssSelector(css));

        foreach (IWebElement elem in elemek)
        {
            return elem;
        }

        return null;
    })!;
}

void Kattint(IWebElement elem)
{
    js.ExecuteScript("arguments[0].scrollIntoView({block:'center'});", elem);
    Thread.Sleep(200);

    try
    {
        elem.Click();
    }
    catch (WebDriverException)
    {
        js.ExecuteScript("arguments[0].click();", elem);
    }

    Thread.Sleep(500);
}

void KattintXpath(string xpath)
{
    Kattint(ElemXpath(xpath));
}

void BeirCss(string css, string szoveg)
{
    IWebElement elem = ElemCss(css);
    elem.Clear();
    elem.SendKeys(szoveg);
}

void FajlFeltolt(string css, string fajl)
{
    IWebElement elem = NyersCss(css);

    js.ExecuteScript(
        "arguments[0].classList.remove('hidden'); arguments[0].style.display='block'; arguments[0].style.opacity='1';",
        elem
    );

    elem.SendKeys(fajl);
}

void SzovegLatszik(string szoveg)
{
    wait.Until(d => d.PageSource.Contains(szoveg));
}

void XpathLatszik(string xpath)
{
    wait.Until(d => d.FindElements(By.XPath(xpath)).Count > 0);
}

void XpathEltunik(string xpath)
{
    wait.Until(d => d.FindElements(By.XPath(xpath)).Count == 0);
}

void FooldalraEr()
{
    wait.Until(d => d.Url.TrimEnd('/') == baseUrl.TrimEnd('/'));
}

void BejelentkezesreEr()
{
    wait.Until(d => d.Url.Contains("/bejelentkezes"));
    SzovegLatszik("Üdv újra!");
}

void AlertElfogad()
{
    IAlert alert = wait.Until(d =>
    {
        try
        {
            return d.SwitchTo().Alert();
        }
        catch (NoAlertPresentException)
        {
            return null;
        }
    })!;

    alert.Accept();
}

try
{
    Megnyit("/");
    js.ExecuteScript("localStorage.clear(); sessionStorage.clear();");
    driver.Manage().Cookies.DeleteAllCookies();

    Futtat("T035", "Főoldal betöltés", () =>
    {
        Megnyit("/");
        SzovegLatszik("FlowFinder");
    });

    Futtat("T036", "Regisztráció", () =>
    {
        Megnyit("/regisztracio");

        BeirCss("input[name='username']", username);
        BeirCss("input[name='email']", email);
        BeirCss("input[name='password']", password);
        BeirCss("input[name='password_confirmation']", password);

        KattintXpath("//button[contains(normalize-space(.),'Regisztráció')]");
        FooldalraEr();
    });

    Futtat("T037", "Kijelentkezés", () =>
    {
        Megnyit("/profil");
        SzovegLatszik("Saját profil");

        KattintXpath("//button[contains(normalize-space(.),'Kijelentkezés')]");
        BejelentkezesreEr();
    });

    Futtat("T038", "Bejelentkezés", () =>
    {
        Megnyit("/bejelentkezes");

        BeirCss("input[name='email']", email);
        BeirCss("input[name='password']", password);

        KattintXpath("//button[contains(normalize-space(.),'Bejelentkezés')]");
        FooldalraEr();
    });

    Futtat("T039", "Profil oldal", () =>
    {
        Megnyit("/profil");

        SzovegLatszik("Saját profil");
        SzovegLatszik(username);
        SzovegLatszik("Általad feltöltött spotok");
    });

    Futtat("T040", "Spot feltöltés", () =>
    {
        Megnyit("/feltoltes");

        BeirCss("input[name='title']", spotCim);
        BeirCss("textarea[name='description']", "Automatikus Selenium teszt spot.");
        BeirCss("input[name='latitude']", "47.4979");
        BeirCss("input[name='longitude']", "19.0402");

        KattintXpath("//span[normalize-space()='BMX']");
        FajlFeltolt("input[type='file']", kepPath);

        KattintXpath("//button[contains(normalize-space(.),'Spot feltöltése')]");

        wait.Until(d => d.Url.Contains("/spotok/"));
        SzovegLatszik(spotCim);
    });

    Futtat("T041", "Spot törlés", () =>
    {
        Megnyit("/profil");

        SzovegLatszik("Általad feltöltött spotok");

        string spotSorXpath = "//h2[normalize-space()='" + spotCim + "']/ancestor::div[contains(@class,'items-stretch')][1]";
        string torlesGombXpath = spotSorXpath + "//button[.//img[@alt='Törlés']]";

        XpathLatszik(spotSorXpath);
        KattintXpath(torlesGombXpath);

        AlertElfogad();
        XpathEltunik(spotSorXpath);
    });

    Futtat("T042", "Végső kijelentkezés", () =>
    {
        Megnyit("/profil");
        SzovegLatszik("Saját profil");

        KattintXpath("//button[contains(normalize-space(.),'Kijelentkezés')]");
        BejelentkezesreEr();
    });

    Console.WriteLine();
    Console.WriteLine("MINDEN TESZT SIKERES!");
}
catch (Exception ex)
{
    Console.WriteLine();
    Console.WriteLine("HIBA:");
    Console.WriteLine(ex.Message);
    throw;
}
finally
{
    driver.Quit();
}